let score = 0;
let round = 1;
let data = new Array(7);
let dataAtRec = new Array(7);
let errorPosition;

function getBitInput(bitId) {
    const bit = document.getElementById(bitId).value;
    return bit === "0" || bit === "1" ? parseInt(bit) : null;
}

function startGame() {
    if (round > 3) {
        document.getElementById("round-info").innerText = "Game over! Thank you for playing.";
        return;
    }

    data[0] = getBitInput("bit0");
    data[1] = getBitInput("bit1");
    data[2] = getBitInput("bit2");
    data[4] = getBitInput("bit4");

    if (data[0] === null || data[1] === null || data[2] === null || data[4] === null) {
        alert("Please enter valid bits (0 or 1) for all positions.");
        return;
    }

    data[6] = data[0] ^ data[2] ^ data[4];
    data[5] = data[0] ^ data[1] ^ data[4];
    data[3] = data[0] ^ data[1] ^ data[2];

    document.getElementById("stored-data").innerText = data.join("");

    dataAtRec = [...data];
    errorPosition = Math.floor(Math.random() * 7);
    dataAtRec[errorPosition] = dataAtRec[errorPosition] === 0 ? 1 : 0;

    document.getElementById("fetched-data").innerText = dataAtRec.join("");
    document.getElementById("round-info").innerText = `--- Round ${round} ---`;
    document.getElementById("error-info").innerText = "";
    document.getElementById("corrected-data").innerText = "";
}

function checkError() {
    const userGuess = parseInt(document.getElementById("error-position").value);

    if (isNaN(userGuess) || userGuess < 1 || userGuess > 7) {
        alert("Please enter a valid position (1-7).");
        return;
    }

    const c1 = dataAtRec[6] ^ dataAtRec[4] ^ dataAtRec[2] ^ dataAtRec[0];
    const c2 = dataAtRec[5] ^ dataAtRec[4] ^ dataAtRec[1] ^ dataAtRec[0];
    const c3 = dataAtRec[3] ^ dataAtRec[2] ^ dataAtRec[1] ^ dataAtRec[0];
    const c = c3 * 4 + c2 * 2 + c1;

    if (c === 0) {
        document.getElementById("error-info").innerText = "No error detected. This should not happen in the game context!";
    } else {
        document.getElementById("error-info").innerText = `Error detected at position: ${c}`;
        if (userGuess === c) {
            document.getElementById("error-info").innerText += " Correct! You identified the error.";
            score++;
        } else {
            document.getElementById("error-info").innerText += ` Incorrect. The error was at position: ${c}`;
        }

        dataAtRec[7 - c] = dataAtRec[7 - c] === 0 ? 1 : 0;
        document.getElementById("corrected-data").innerText = dataAtRec.join("");
    }

    document.getElementById("score").innerText = `Score: ${score}`;
    round++;
}